Specs
=====

This section contains detailed specification documents for
different features inside Karbor Client.

Approved Specs
--------------

.. toctree::
    :maxdepth: 1

    karbor-support-in-python-openstackclient
