============
Installation
============

At the command line::

    $ pip install python-karborclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-karborclient
    $ pip install python-karborclient
