============
Contributing
============

General Info
------------

.. include:: ../../../CONTRIBUTING.rst

Approved Specs
--------------

.. toctree::
   :maxdepth: 1

   ../specs/index
